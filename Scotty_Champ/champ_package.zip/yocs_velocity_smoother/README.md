# champ_teleop
Champ Quadruped Robot's teleoperation node. This is a forked version of [yocs_velocity_smooter](https://github.com/yujinrobot/yujin_ocs). 

The software has been modified to add support velocity smoothing in the y axis.
